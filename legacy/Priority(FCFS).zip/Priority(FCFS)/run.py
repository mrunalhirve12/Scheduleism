import randomprocess as f
import priority as sf

lisbt = []
lispriority = []

if __name__ == '__main__':
    print("Enter the number of process:")
    n = int(input())

    x = f.generator(n)

    no_process = len(x)

    for i in range(len(x)):
        lisbt.append(x[i][3])
        lispriority.append(x[i][4])

    sf.priority(no_process, lisbt,lispriority)
