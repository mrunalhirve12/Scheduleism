import randomprocess as f
import s as sf

lis = []

if __name__ == '__main__':
    print("Enter the number of process:")
    n = int(input())

    x = f.generator(n)

    no_process = len(x)

    for i in range(len(x)):
        lis.append(x[i][3])

    sf.shortest(no_process, lis)
